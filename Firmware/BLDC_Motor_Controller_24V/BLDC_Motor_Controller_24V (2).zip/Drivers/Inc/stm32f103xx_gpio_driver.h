/*
 * stm32f103xx_gpio.h
 *
 *  Created on: Dec 18, 2020
 *      Author: Ganghyeok Lim
 */

#ifndef INC_STM32F103XX_GPIO_DRIVER_H_
#define INC_STM32F103XX_GPIO_DRIVER_H_

#include "stm32f103xx.h"


/*=============================================================================================================================*/


/**
  * @brief GPIO Init structure definition
  */
typedef struct
{
  uint32_t Pin;       /*!< Specifies the GPIO pins to be configured.
                           This parameter can be any value of @ref GPIO_pins_define */

  uint32_t Mode;      /*!< Specifies the operating mode for the selected pins.
                           This parameter can be a value of @ref GPIO_mode_define */

  uint32_t Pull;      /*!< Specifies the Pull-up or Pull-Down activation for the selected pins.
                           This parameter can be a value of @ref GPIO_pull_define */

  uint32_t Speed;     /*!< Specifies the speed for the selected pins.
                           This parameter can be a value of @ref GPIO_speed_define */
} GPIO_InitTypeDef;


/**
  * @brief  GPIO handle Structure definition
  */
typedef struct
{
	GPIO_TypeDef		*Instance;		/*!< GPIO registers base address        */

	GPIO_InitTypeDef	Init;			/*!< GPIO configuration parameters      */

} GPIO_HandleTypeDef;


/*=============================================================================================================================*/


/** @defgroup GPIO_pins_define GPIO pins define
  * @{
  */
#define GPIO_PIN_0                 ((uint16_t)0x0001)		/* Pin 0 selected    */
#define GPIO_PIN_1                 ((uint16_t)0x0002)		/* Pin 1 selected    */
#define GPIO_PIN_2                 ((uint16_t)0x0004)  		/* Pin 2 selected    */
#define GPIO_PIN_3                 ((uint16_t)0x0008)  		/* Pin 3 selected    */
#define GPIO_PIN_4                 ((uint16_t)0x0010)  		/* Pin 4 selected    */
#define GPIO_PIN_5                 ((uint16_t)0x0020)  		/* Pin 5 selected    */
#define GPIO_PIN_6                 ((uint16_t)0x0040)  		/* Pin 6 selected    */
#define GPIO_PIN_7                 ((uint16_t)0x0080)  		/* Pin 7 selected    */
#define GPIO_PIN_8                 ((uint16_t)0x0100)  		/* Pin 8 selected    */
#define GPIO_PIN_9                 ((uint16_t)0x0200)  		/* Pin 9 selected    */
#define GPIO_PIN_10                ((uint16_t)0x0400)  		/* Pin 10 selected   */
#define GPIO_PIN_11                ((uint16_t)0x0800)  		/* Pin 11 selected   */
#define GPIO_PIN_12                ((uint16_t)0x1000)  		/* Pin 12 selected   */
#define GPIO_PIN_13                ((uint16_t)0x2000)  		/* Pin 13 selected   */
#define GPIO_PIN_14                ((uint16_t)0x4000)  		/* Pin 14 selected   */
#define GPIO_PIN_15                ((uint16_t)0x8000)  		/* Pin 15 selected   */
#define GPIO_PIN_All               ((uint16_t)0xFFFF)  		/* All pins selected */

#define GPIO_PIN_MASK              0x0000FFFFu 				/* PIN mask for assert test */


/** @defgroup GPIO_mode_define GPIO mode define
  * @brief GPIO Configuration Mode
  *        Elements values convention: 0xX0yz00YZ
  *           - X  : GPIO mode or EXTI Mode
  *           - y  : External IT or Event trigger detection
  *           - z  : IO configuration on External IT or Event
  *           - Y  : Output type (Push Pull or Open Drain)
  *           - Z  : IO Direction mode (Input, Output, Alternate or Analog)
  * @{
  */
#define  GPIO_MODE_INPUT                        0x00000000u   		/*!< Input Floating Mode                   */
#define  GPIO_MODE_OUTPUT_PP                    0x00000001u   		/*!< Output Push Pull Mode                 */
#define  GPIO_MODE_OUTPUT_OD                    0x00000011u   		/*!< Output Open Drain Mode                */
#define  GPIO_MODE_AF_PP                        0x00000002u   		/*!< Alternate Function Push Pull Mode     */
#define  GPIO_MODE_AF_OD                        0x00000012u   		/*!< Alternate Function Open Drain Mode    */
#define  GPIO_MODE_AF_INPUT                     GPIO_MODE_INPUT     /*!< Alternate Function Input Mode         */

#define  GPIO_MODE_ANALOG                       0x00000003u   		/*!< Analog Mode  */

#define  GPIO_MODE_IT_RISING                    0x10110000u   		/*!< External Interrupt Mode with Rising edge trigger detection          */
#define  GPIO_MODE_IT_FALLING                   0x10210000u   		/*!< External Interrupt Mode with Falling edge trigger detection         */
#define  GPIO_MODE_IT_RISING_FALLING            0x10310000u   		/*!< External Interrupt Mode with Rising/Falling edge trigger detection  */

#define  GPIO_MODE_EVT_RISING                   0x10120000u   		/*!< External Event Mode with Rising edge trigger detection               */
#define  GPIO_MODE_EVT_FALLING                  0x10220000u   		/*!< External Event Mode with Falling edge trigger detection              */
#define  GPIO_MODE_EVT_RISING_FALLING           0x10320000u   		/*!< External Event Mode with Rising/Falling edge trigger detection       */


/** @defgroup GPIO_speed_define  GPIO speed define
  * @brief GPIO Output Maximum frequency
  * @{
  */
#define  GPIO_SPEED_FREQ_LOW              (GPIO_CRL_MODE0_1) 		/*!< Low speed */
#define  GPIO_SPEED_FREQ_MEDIUM           (GPIO_CRL_MODE0_0) 		/*!< Medium speed */
#define  GPIO_SPEED_FREQ_HIGH             (GPIO_CRL_MODE0)   		/*!< High speed */


/** @defgroup GPIO_pull_define GPIO pull define
  * @brief GPIO Pull-Up or Pull-Down Activation
  * @{
  */
#define  GPIO_NOPULL        0x00000000u   		/*!< No Pull-up or Pull-down activation  */
#define  GPIO_PULLUP        0x00000001u   		/*!< Pull-up activation                  */
#define  GPIO_PULLDOWN      0x00000002u   		/*!< Pull-down activation                */


/**************************************************************************************************************
 * 																											  *
 * 												User Macro Definition										  *
 * 									  																		  *
 **************************************************************************************************************/

#define EXTI_MODE				0x10000000U
#define GPIO_MODE_IT			0x00010000U
#define GPIO_MODE_EVT			0x00020000U
#define RISING_EDGE				0x00100000U
#define FALLING_EDGE			0x00200000U
#define GPIO_OUTPUT_TYPE		0x00000010U


/**************************************************************************************************************
 * 																											  *
 * 												User Macro Function											  *
 * 									  																		  *
 **************************************************************************************************************/

#define GET_GPIOCODE(x)				  ( (x == GPIOA) ? 0 : \
										(x == GPIOB) ? 1 : \
										(x == GPIOC) ? 2 : \
										(x == GPIOD) ? 3 : \
										(x == GPIOE) ? 4 : \
										(x == GPIOF) ? 5 : 6 )


#define GPIOx_ClockEnable(x)		  ( (x == GPIOA) ? RCC_GPIOA_CLK_ENABLE() : \
										(x == GPIOB) ? RCC_GPIOB_CLK_ENABLE() : \
										(x == GPIOC) ? RCC_GPIOC_CLK_ENABLE() : \
										(x == GPIOD) ? RCC_GPIOD_CLK_ENABLE() : \
										(x == GPIOE) ? RCC_GPIOE_CLK_ENABLE() : \
										(x == GPIOF) ? RCC_GPIOF_CLK_ENABLE() : RCC_GPIOG_CLK_ENABLE() )

#define AFIO_REMAP_PARTIAL(REMAP_PIN, REMAP_PIN_MASK) do{ uint32_t tmpreg = AFIO->MAPR; \
                                                          tmpreg &= ~REMAP_PIN_MASK;    \
                                                          tmpreg |= AFIO_MAPR_SWJ_CFG;  \
                                                          tmpreg |= REMAP_PIN;          \
                                                          AFIO->MAPR = tmpreg;          \
                                                          }while(0u)

#define AFIO_DBGAFR_CONFIG(DBGAFR_SWJCFG)  do{ uint32_t tmpreg = AFIO->MAPR;     \
                                               tmpreg &= ~AFIO_MAPR_SWJ_CFG_Msk; \
                                               tmpreg |= DBGAFR_SWJCFG;          \
                                               AFIO->MAPR = tmpreg;              \
                                               }while(0u)


#define AFIO_REMAP_TIM3_ENABLE()  AFIO_REMAP_PARTIAL(AFIO_MAPR_TIM3_REMAP_FULLREMAP, AFIO_MAPR_TIM3_REMAP_FULLREMAP)


/**
  * @brief Enable the Serial wire JTAG configuration
  * @note  NOJTAG: JTAG-DP Disabled and SW-DP Enabled
  * @retval None
  */
#define AFIO_REMAP_SWJ_NOJTAG()  AFIO_DBGAFR_CONFIG(AFIO_MAPR_SWJ_CFG_JTAGDISABLE)

/**************************************************************************************************************
 * 																											  *
 * 											APIs supported by this driver									  *
 * 						For more information about the APIs, Check the function definitions					  *
 * 									  																		  *
 **************************************************************************************************************/

/* Initialization and de-initialization functions *****************************/
void GPIO_Init(GPIO_TypeDef  *GPIOx, GPIO_InitTypeDef *GPIO_Init);
void GPIO_DeInit(GPIO_TypeDef  *GPIOx, uint32_t GPIO_Pin);

/* IO operation functions *****************************************************/
uint8_t GPIO_ReadPin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void GPIO_WritePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, uint8_t PinState);
void GPIO_ModifyPin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin_To_Set, uint16_t GPIO_Pin_To_Reset);
void GPIO_WritePort(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, uint8_t PinState);
void GPIO_WriteData(GPIO_TypeDef *GPIOx, uint16_t Data);
void GPIO_TogglePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void EXTI_IRQHandling(uint32_t GPIO_Pin);
void EXTI_Callback(uint32_t GPIO_Pin);


#endif /* INC_STM32F103XX_GPIO_DRIVER_H_ */
