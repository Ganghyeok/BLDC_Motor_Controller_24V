
data = importdata('teraterm.log');
length = numel(data);
t = 0 : 0.05 : ((length - 1) * 0.05);
plot(t', data);

title('Kp = 0.01, Ki = 0.10', 'Fontsize', 14);
xlabel('t [sec]', 'Fontsize', 12);
ylabel('Speed [rpm]', 'Fontsize', 14);
grid on;

delete teraterm.log;
clc; clear;